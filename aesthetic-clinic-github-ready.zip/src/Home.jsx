import { useState } from "react";
import { Stethoscope, MonitorSmartphone, ShieldCheck, Smile, HeartPulse, Wand2, Star, PhoneCall } from "lucide-react";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";

export default function Home() {
  const [formData, setFormData] = useState({
    service: "البوتوكس",
    date: "",
    time: "",
    name: "",
    phone: ""
  });

  const [showAlert, setShowAlert] = useState(false);
  const [language, setLanguage] = useState("ar");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
      });

      if (!response.ok) throw new Error("حدث خطأ أثناء إرسال البيانات.");

      setShowAlert(true);
      const message = `أرغب بحجز موعد لـ ${formData.service}%0Aالتاريخ: ${formData.date}%0Aالوقت: ${formData.time}%0Aالاسم: ${formData.name}%0Aرقم الجوال: ${formData.phone}`;
      const whatsappURL = `https://wa.me/966509311215?text=${message}`;
      window.open(whatsappURL, "_blank");
    } catch (error) {
      alert("حدث خطأ أثناء إرسال الحجز. يرجى المحاولة مرة أخرى.");
    }
  };

  const isAr = language === "ar";

  return (
    <main className="min-h-screen bg-gray-50 text-gray-800 relative" dir={isAr ? "rtl" : "ltr"}>
      <header className="bg-blue-600 text-white py-10 text-center">
        <div className="flex justify-between items-center max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mx-auto text-center w-full">{isAr ? "عيادتنا للتجميل" : "Our Aesthetic Clinic"}</h1>
          <div className="absolute top-4 right-6 flex space-x-2">
            <button
              onClick={() => setLanguage("ar")}
              className={`flex items-center px-2 py-1 rounded font-bold ${language === "ar" ? "bg-white text-blue-600" : "text-white"}`}
            >
              🇸🇦 <span className="ml-1">العربية</span>
            </button>
            <button
              onClick={() => setLanguage("en")}
              className={`flex items-center px-2 py-1 rounded font-bold ${language === "en" ? "bg-white text-blue-600" : "text-white"}`}
            >
              🇬🇧 <span className="ml-1">EN</span>
            </button>
            <a
              href="/dashboard"
              className="ml-2 px-3 py-1 rounded bg-white text-blue-600 font-bold hover:bg-gray-100 transition"
            >
              {isAr ? "لوحة التحكم" : "Dashboard"}
            </a>
          </div>
        </div>
        <p className="text-sm mt-2">{isAr ? "نمنحك جمالاً يليق بك" : "We bring out your beauty"}</p>
      </header>

      <a
        href="tel:966509311215"
        className="fixed bottom-6 right-6 bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700 transition-all z-50"
        title={isAr ? "اتصل بنا" : "Call us"}
      >
        <PhoneCall size={24} />
      </a>

      <section className="py-12 bg-white text-center">
        <h2 className="text-2xl font-bold mb-6">{isAr ? "خدماتنا" : "Our Services"}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto px-4">
          {["البوتوكس", "الفيلر", "تنظيف البشرة", "الليزر", "العناية بالبشرة", "إزالة التصبغات"].map((service, index) => (
            <div
              key={index}
              className="bg-blue-100 hover:shadow-xl transition-transform hover:scale-105 hover:brightness-110 rounded-xl p-6 cursor-pointer"
              style={{ borderRadius: '1rem' }}
            >
              <HeartPulse className="mx-auto mb-4 text-blue-600" size={40} />
              <h3 className="text-lg font-semibold">{service}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 bg-blue-700 text-white text-center">
        <h2 className="text-2xl font-bold mb-6">{isAr ? "مميزاتنا" : "Why Choose Us"}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto px-4">
          {[
            { icon: <Stethoscope size={32} />, label: isAr ? "أطباء متخصصون" : "Specialist Doctors" },
            { icon: <MonitorSmartphone size={32} />, label: isAr ? "حجز إلكتروني سهل" : "Easy Online Booking" },
            { icon: <ShieldCheck size={32} />, label: isAr ? "تعقيم عالي المستوى" : "High-Level Hygiene" },
            { icon: <Smile size={32} />, label: isAr ? "نتائج مضمونة" : "Guaranteed Results" }
          ].map((item, i) => (
            <div key={i} className="bg-white text-blue-800 rounded-2xl p-6 shadow">
              <div className="mb-3">{item.icon}</div>
              <p>{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 bg-gray-100 text-center">
        <h2 className="text-2xl font-bold mb-6">{isAr ? "احجز موعدك الآن" : "Book Your Appointment"}</h2>
        <form onSubmit={handleSubmit} className="max-w-xl mx-auto bg-white p-6 rounded-2xl shadow">
          <div className="grid gap-4 mb-4">
            <select name="service" onChange={handleChange} className="p-2 rounded border">
              {["البوتوكس", "الفيلر", "تنظيف البشرة"].map((s, i) => (
                <option key={i} value={s}>{s}</option>
              ))}
            </select>
            <input type="date" name="date" onChange={handleChange} className="p-2 rounded border" />
            <input type="time" name="time" onChange={handleChange} className="p-2 rounded border" />
            <input type="text" name="name" placeholder={isAr ? "الاسم" : "Name"} onChange={handleChange} className="p-2 rounded border" />
            <input type="tel" name="phone" placeholder={isAr ? "رقم الجوال" : "Phone Number"} onChange={handleChange} className="p-2 rounded border" />
          </div>
          <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition">
            {isAr ? "إرسال" : "Submit"}
          </button>
          {showAlert && <p className="mt-4 text-green-600">{isAr ? "تم الإرسال بنجاح! سيتم التواصل معك قريبًا." : "Submitted successfully! We will contact you soon."}</p>}
        </form>
      </section>

      <section className="py-12 bg-blue-100 text-center">
        <h2 className="text-2xl font-bold mb-6">{isAr ? "آراء العملاء" : "Customer Reviews"}</h2>
        <div className="max-w-4xl mx-auto px-4">
          <Carousel showThumbs={false} infiniteLoop autoPlay interval={5000} showStatus={false}>
            {[1, 2, 3].map((r) => (
              <div key={r} className="bg-white p-6 rounded-2xl shadow text-left">
                <p className="mb-2">{isAr ? "خدمة ممتازة وطاقم رائع!" : "Excellent service and great staff!"}</p>
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="text-yellow-400" size={20} />)}
                </div>
              </div>
            ))}
          </Carousel>
        </div>
      </section>

      <footer className="bg-blue-800 text-white text-center p-4 mt-12">
        <p>{isAr ? "جميع الحقوق محفوظة © 2025" : "All rights reserved © 2025"}</p>
        <div className="mt-2">
          <a href="https://www.instagram.com/wad7.sa" target="_blank" rel="noopener noreferrer" className="underline hover:text-gray-300">
            {isAr ? "تصميم وتطوير وضح" : "Design & Development by Wad7"}
          </a>
        </div>
      </footer>
    </main>
  );
}